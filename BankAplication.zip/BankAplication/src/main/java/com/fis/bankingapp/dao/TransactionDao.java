package com.fis.bankingapp.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.fis.bankingapp.model.Transaction;

public interface TransactionDao extends JpaRepository<Transaction,Integer> {
	// This is the interface in dao layer for transactions
	
	//public List<Transaction> showTransactionData();
	//public String addTransaction(Transaction transaction);
	@Query("select t from Transaction t where t.fromaccount=?1")
	public List<Transaction> getTransactionByAcc(long getAcc);

}
