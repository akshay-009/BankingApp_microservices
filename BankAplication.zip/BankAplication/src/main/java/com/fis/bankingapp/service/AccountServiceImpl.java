package com.fis.bankingapp.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankingapp.dao.AccountDao;
import com.fis.bankingapp.exceptions.AccountNotFound;
import com.fis.bankingapp.exceptions.NotEnoughBalance;
import com.fis.bankingapp.model.Account;

@Service
@Transactional
public class AccountServiceImpl implements AccountService {
	@Autowired
	AccountDao dao;
	
	@Override
	public String createAccount(Account account) {
		// TODO Auto-generated method stub
		dao.save(account);
		return "Account Created Successfully";
	}

	@Override
	public Account getAccount(long getAcc) throws AccountNotFound {
		// TODO Auto-generated method stub
		Optional<Account> optional = dao.findById(getAcc);
		if (optional.isPresent()) {
			return optional.get();
		} else {
			throw new AccountNotFound("Account Not Found");
		}
	
	}

	@Override
	public List<Account> getAllAccounts() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	@Override
	public String updateAccount(Account account) {
		// TODO Auto-generated method stub
		dao.save(account);
		return "Account Updated Successfully";
	}

	@Override
	public String deleteAccount(long getacc) throws AccountNotFound{
		// TODO Auto-generated method stub
		dao.deleteById(getacc);
		return "Account Deleted Successfully";
		
	}
	// This method is to deposit money to account.
	@Override
	public String deposit(long getAcc, double depositAmount) throws AccountNotFound {
		// TODO Auto-generated method stub
		Optional<Account> optional = dao.findById(getAcc);
		if (optional.isPresent()) {
			//optional.get();
			dao.deposit(getAcc, depositAmount);
			return "Amount Deposited Successfully";
		} else {
			throw new AccountNotFound("Account Not Found");
		}	
	}

	// This method is to withdraw money from account.
	@Override
	public String withdraw(long getAcc, double withdrawAmount ) throws AccountNotFound, NotEnoughBalance {
		// TODO Auto-generated method stub
		Optional<Account> optional = dao.findById(getAcc);
		if (optional.isPresent()) {
		  if(optional.get().getBalance()>withdrawAmount) {
			  dao.withdraw(getAcc, withdrawAmount);
			  return "Amount Withdrawed Successfully"; 
		  }
		  else {
			  throw new NotEnoughBalance("Not Enough Balance");
		  }
		  
		} else {
			throw new AccountNotFound("Account Not Found");
		}
		
		
	}

	// In the fund transfer i'm using above withdraw and deposit method to do transfer fromAcc to toAcc
	@Override
	public String fundTransfer(long fromAcc, long toAcc, double amount) throws AccountNotFound, NotEnoughBalance {
		// TODO Auto-generated method stub
		Optional<Account> optional = dao.findById(fromAcc);
		Optional<Account> optional1 = dao.findById(toAcc);
		if(optional.isPresent() && optional1.isPresent()) {
			if(optional.get().getBalance()>amount) {
				  dao.withdraw(fromAcc, amount);
				  dao.deposit(toAcc, amount);
				  return "Fund Transfer Successfully"; 
			  }
			  else {
				  throw new NotEnoughBalance("Not Enough Balance");
			  }
		}
		else {
			throw new AccountNotFound("Account Not Found");
		}
		
	}

//	@Override
//	public Double interestEarned(long getAcc, Date todaydate) {
//		// TODO Auto-generated method stub
//		return dao.interestEarned(getAcc, todaydate);
//	}



}
