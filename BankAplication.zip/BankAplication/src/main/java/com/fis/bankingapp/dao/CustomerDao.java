package com.fis.bankingapp.dao;

//import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.fis.bankingapp.model.Customer;

public interface CustomerDao extends JpaRepository<Customer,Integer>{
	// This is the interface in dao layer for customer transactions
//	public String createCustomer(Customer customer );
//	public List<Customer> showCustomerData();
}
